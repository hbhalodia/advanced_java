package com.bascis.springfundamentals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringfundamentalsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringfundamentalsApplication.class, args);
	}

}
