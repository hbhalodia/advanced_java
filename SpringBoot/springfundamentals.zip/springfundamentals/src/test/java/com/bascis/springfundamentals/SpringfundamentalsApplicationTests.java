package com.bascis.springfundamentals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringfundamentalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
